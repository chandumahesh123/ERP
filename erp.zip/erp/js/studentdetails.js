var classno = document.getElementById('classno');
var section = document.getElementById('section');
var table = document.getElementById('table');
var tabledata = $('#zero_config').DataTable();

function getData(button){
    
    classno.className = "form-control";
    tabledata.clear().draw();
    
    if(!classno.value){
        
        classno.className = "form-control is-invalid";
    }
    else{
        
        var ref = firebase.firestore().collection("students2020").where("class", "==", classno.value);
        ref.get().then((snapshot) => {
            
            snapshot.forEach((stu) => {
                
                var key = stu.id;
                var s1 = stu.data().admno;
                var s2 = stu.data().name;
                var s3 = stu.data().class+"("+stu.data().section+")";
                var s4 = stu.data().father.fname;
                var s5 = stu.data().dob;
                var s6 = stu.data().gender;
                var s7 = stu.data().ph;
                var s8 = '<a href="stuinfo.html?a='+key+'"><i class="fas fa-bars" title="Show"></i></a>&nbsp;&nbsp;&nbsp;<a href="stuedit.html?a='+key+'"><i class="fas fa-edit" title="Edit"></i></a>&nbsp;&nbsp;&nbsp;<a href="addfees.html?a='+key+'"><i class="fas fa-dollar-sign" title="Add Fees"></i></a>';
                
                var dataSet = [s1,s2,s3,s4,s5,s6,s7,s8];
            
                if(section.value){
                    
                    if(section.value == stu.data().section){
                        tabledata.rows.add([dataSet]).draw();
                    }
                }
                else{
                    tabledata.rows.add([dataSet]).draw();
                }
                
            });
            
            table.style.display = "block";
        })
        .catch((error) => {
            
            console.log("Error getting documents: ", error);
        });
    }
}
