const queryString = window.location.search;
const urlParams = new URLSearchParams(queryString);
const a = urlParams.get('a');

if(!a){
    location.replace("error.html");
}
    
    var s1 = document.getElementById('s1');
    var s2 = document.getElementById('s2');
    var s3 = document.getElementById('s3');
    var s4 = document.getElementById('s4');
    var s5 = document.getElementById('s5');
    var s6 = document.getElementById('s6');
    var s7 = document.getElementById('s7');
    var s8 = document.getElementById('s8');
    var s9 = document.getElementById('s9');
    var s10 = document.getElementById('s10');
    var s11 = document.getElementById('s11');
    var s12 = document.getElementById('s12');
    var s13 = document.getElementById('s13');
    var s14 = document.getElementById('s14');
    var s15 = document.getElementById('s15');
    var s16 = document.getElementById('s16');
    
    var p1 = document.getElementById('p1');
    var p2 = document.getElementById('p2');
    var p3 = document.getElementById('p3');
    var p4 = document.getElementById('p4');
    var p5 = document.getElementById('p5');
    var p6 = document.getElementById('p6');
    var p7 = document.getElementById('p7');
    var p8 = document.getElementById('p8');
    var p9 = document.getElementById('p9');
    var p10 = document.getElementById('p10');
    var p11 = document.getElementById('p11');

    var success = document.getElementById('success');
    var error = document.getElementById('error');
    
    var docRef = firebase.firestore().collection("students2020").doc(a);
    docRef.get().then((doc) => {
        
        if (doc.exists) {
            
            s1.value = doc.data().admno;
            s2.value = doc.data().roll;
            s3.value = doc.data().class;
            s4.value = doc.data().section;
            s5.value = doc.data().name;
            s6.value = doc.data().last;
            s7.value = doc.data().gender;
            s8.value = doc.data().dob;
            s9.value = doc.data().cate;
            s10.value = doc.data().reli;
            s11.value = doc.data().caste;
            s12.value = doc.data().ph;
            s13.value = doc.data().email;
            s14.value = doc.data().admdate;
            s16.value = doc.data().blood;
            
            p1.value = doc.data().father.fname;
            p2.value = doc.data().father.fphone;
            p3.value = doc.data().father.focc;
            p4.value = doc.data().mother.mname;
            p5.value = doc.data().mother.mphone;
            p6.value = doc.data().mother.mocc;
            p7.value = doc.data().guardian.gname;
            p8.value = doc.data().guardian.grel;
            p9.value = doc.data().guardian.gphone;
            p10.value = doc.data().guardian.gocc;
            p11.value = doc.data().guardian.gadd;
            
        } else {
            
            // console.log("No such document!");
        }
    }).catch((error) => {
        
        console.log("Error getting document:", error);
    });


function studentRegister(button){
    
    button.disabled = true;
    
    success.innerHTML = "";
    error.innerHTML = "";
    
    s1.className = "form-control";
    s3.className = "form-control";
    s4.className = "form-control";
    s5.className = "form-control";
    s7.className = "form-control";
    s8.className = "form-control";
    p7.className = "form-control";
    p9.className = "form-control";
    
    if(!s1.value || !s3.value || !s4.value || !s5.value || !s7.value || !s8.value || !p7.value || !p9.value) {
        
        if(!s1.value) s1.className = "form-control is-invalid";
        if(!s3.value) s3.className = "form-control is-invalid";
        if(!s4.value) s4.className = "form-control is-invalid";
        if(!s5.value) s5.className = "form-control is-invalid";
        if(!s7.value) s7.className = "form-control is-invalid";
        if(!s8.value) s8.className = "form-control is-invalid";
        if(!p7.value) p7.className = "form-control is-invalid";
        if(!p9.value) p9.className = "form-control is-invalid";
        button.disabled = false;
    }
    else{
                
        if(s15.value){
        
            var uploadTask=firebase.storage().ref('/studentimages/'+s1.value+s15.files[0].name).put(s15.files[0]);
                    
            uploadTask.on('state_changed', function(snapshot){
                        
                var progress=(snapshot.bytesTransferred/snapshot.totalBytes)*100;
                // console.log("Upload" + progress);
            },function(error){
                error.innerHTML = "<i class='fas fa-exclamation-circle'></i><b>&nbsp;"+error.message+"</b>&nbsp;";
                // alert(error.message);
                button.disabled = false;
                    
            },function(){
                        
                uploadTask.snapshot.ref.getDownloadURL().then(function(downloadURL){
                            
                    putData(button, downloadURL);
                });
            });
                    
        }
        else{
                    
            putData(button, "");
        }
    }
}

function putData(button, url){
        
        var db = firebase.firestore();
        db.collection("students2020").doc(s1.value).update({
            
            admno: s1.value,
            roll: s2.value,
            class: s3.value,
            section: s4.value,
            name: s5.value,
            last: s6.value,
            gender: s7.value,
            dob: s8.value,
            cate: s9.value,
            reli: s10.value,
            caste: s11.value,
            ph: s12.value,
            email: s13.value,
            admdate: s14.value,
            photo: url,
            blood: s16.value,
            father: {
                fname: p1.value,
                fphone: p2.value,
                focc: p3.value
            },
            mother: {
                mname: p4.value,
                mphone: p5.value,
                mocc: p6.value
            },
            guardian: {
                gname: p7.value,
                grel: p8.value,
                gphone: p9.value,
                gocc: p10.value,
                gadd: p11.value
            }
        }).then((docRef) => {
            // document.getElementById('form').reset();
            success.innerHTML = "<i class='fas fa-check-circle'></i><b>&nbsp;Record Saved Successfully</b>&nbsp;";
            button.disabled = false;
            
        }).catch((error) => {
            error.innerHTML = "<i class='fas fa-exclamation-circle'></i><b>&nbsp;"+error+"</b>&nbsp;";
            // console.error("Error writing document: ", error);
            button.disabled = false;
        }); 
        
}