const queryString = window.location.search;
const urlParams = new URLSearchParams(queryString);
const a = urlParams.get('a');

if(!a){
    location.replace("error.html");
}
    
    var s = document.getElementById('s');
    var s1 = document.getElementById('s1');
    var s2 = document.getElementById('s2');
    var s3 = document.getElementById('s3');
    var s4 = document.getElementById('s4');
    var s5 = document.getElementById('s5');
    var s6 = document.getElementById('s6');
    var s7 = document.getElementById('s7');
    var s8 = document.getElementById('s8');
    var s9 = document.getElementById('s9');
    var s10 = document.getElementById('s10');
    var s11 = document.getElementById('s11');
    var s12 = document.getElementById('s12');
    
    var p1 = document.getElementById('p1');
    var p2 = document.getElementById('p2');
    var p3 = document.getElementById('p3');
    var p4 = document.getElementById('p4');
    var p5 = document.getElementById('p5');
    var p6 = document.getElementById('p6');
    var p7 = document.getElementById('p7');
    var p8 = document.getElementById('p8');
    var p9 = document.getElementById('p9');
    var p10 = document.getElementById('p10');

    var success = document.getElementById('success');
    var error = document.getElementById('error');
    var image = document.getElementById('image');
    var anc = document.getElementById('anc');
    
    var docRef = firebase.firestore().collection("students2020").doc(a);
    docRef.get().then((doc) => {
        
        if (doc.exists) {

            s.innerHTML = doc.data().name + " " + doc.data().last;
            s1.innerHTML = doc.data().admno;
            s2.innerHTML = doc.data().roll;
            s3.innerHTML = doc.data().class;
            s4.innerHTML = doc.data().section;
            s5.innerHTML = doc.data().gender;
            s6.innerHTML = doc.data().admdate;
            s7.innerHTML = doc.data().dob;
            s8.innerHTML = doc.data().cate;
            s9.innerHTML = doc.data().ph;
            s10.innerHTML = doc.data().caste;
            s11.innerHTML = doc.data().reli;
            s12.innerHTML = doc.data().email;
            
            p1.innerHTML = doc.data().father.fname;
            p2.innerHTML = doc.data().father.fphone;
            p3.innerHTML = doc.data().father.focc;
            p4.innerHTML = doc.data().mother.mname;
            p5.innerHTML = doc.data().mother.mphone;
            p6.innerHTML = doc.data().mother.mocc;
            p7.innerHTML = doc.data().guardian.gname;
            p8.innerHTML = doc.data().guardian.grel;
            p9.innerHTML = doc.data().guardian.gphone;
            p10.innerHTML = doc.data().guardian.gocc;
            p11.innerHTML = doc.data().guardian.gadd;
            
            if(doc.data().photo)
                image.src = doc.data().photo;
                
            anc.href = 'stuedit.html?a='+doc.id;
        }
        else {
            
            // console.log("No such document!");
        }
    }).catch((error) => {
        
        console.log("Error getting document:", error);
    });

