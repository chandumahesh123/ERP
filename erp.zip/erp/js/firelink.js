var firebaseConfig = {
    apiKey: "AIzaSyDbucmfl0Ls_M5kWR_GOVuXoVdAOCZqjQE",
    authDomain: "school-erp-876a4.firebaseapp.com",
    databaseURL: "https://school-erp-876a4-default-rtdb.firebaseio.com",
    projectId: "school-erp-876a4",
    storageBucket: "school-erp-876a4.appspot.com",
    messagingSenderId: "116154858735",
    appId: "1:116154858735:web:de1b28e6b4562623fe6f1a",
    measurementId: "G-CYCKPYJCN7"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
  firebase.analytics();
  
  
function refresh() 
{ 
    window.location.reload();
} 

function logout() {
    
    
    sessionStorage.clear();
    // alert('Logout Success');
    window.location = "../index.html";
}