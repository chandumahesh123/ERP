var classno = document.getElementById('classno');
var section = document.getElementById('section');
var datefield = document.getElementById('datefield');
var table = document.getElementById('table');
var tabledata = $('#zero_config').DataTable();

datefield.valueAsDate = new Date();

function getData(button){
    
    classno.className = "form-control";
    section.className = "form-control";
    tabledata.clear().draw();
    
    if(!classno.value){
        
        classno.className = "form-control is-invalid";
    }
    else if(!section.value){
        
        section.className = "form-control is-invalid";
    }
    else{
        
        var ref = firebase.firestore().collection("students2020").where("class", "==", classno.value).where("section", "==", section.value);
        ref.get().then((snapshot) => {
            
            snapshot.forEach((stu) => {
                
                var key = stu.id;
                var s1 = stu.data().admno;
                var s2 = stu.data().roll;
                var s3 = stu.data().name;
                var radio1 = '<div class="row"><div class="custom-control custom-radio"><input type="radio" class="custom-control-input" id="ccv1" name="radio" checked><label class="custom-control-label" for="ccv1">Present</label></div>&nbsp;&nbsp;&nbsp;&nbsp';
                var radio2 = '<div class="custom-control custom-radio"><input type="radio" class="custom-control-input" id="ccv2" name="radio"><label class="custom-control-label" for="ccv2">Absent</label></div>&nbsp;&nbsp;&nbsp;&nbsp;';
                var radio3 = '<div class="custom-control custom-radio"><input type="radio" class="custom-control-input" id="ccv3" name="radio"><label class="custom-control-label" for="ccv3">Half Day</label></div></div>';                       
                var s4 = radio1 + radio2 + radio3;                 
                
                var dataSet = [s1,s2,s3,s4];
                
                tabledata.rows.add([dataSet]).draw();
                
            });
            
            table.style.display = "block";
        })
        .catch((error) => {
            
            console.log("Error getting documents: ", error);
        });
    }
}
